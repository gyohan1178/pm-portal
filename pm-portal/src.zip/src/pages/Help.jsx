// 도움말 / 신규사원 셀프 온보딩 페이지
// 전체 업무 플로우 + 시작 가이드 + 메뉴별 설명

const FLOW = [
  { sys:'이카운트', title:'주문서 등록', desc:'고객사 PO를 이카운트에 등록 → 내려받기' },
  { sys:'포털',     title:'PO 업로드',  desc:'내려받은 주문서를 고객사 탭에 업로드' },
  { sys:'포털',     title:'부족자재 산출', desc:'PO × BOM 소요 − (재고 + 입고예정)' },
  { sys:'포털',     title:'구매발주',    desc:'부족분 발주 → 발주서 양식으로 내려받기' },
  { sys:'이카운트', title:'발주서 입력', desc:'내려받은 발주를 이카운트에 올리기' },
  { sys:'포털',     title:'입고처리',    desc:'협력사·담당자 검색 → 발주건 입고' },
  { sys:'포털',     title:'출고·불출',   desc:'PO 기준 소요 산출, 납기순 배분 + 미불출 추적' },
]

const START_STEPS = [
  '회원가입 신청 후 관리자 승인을 받으면 포털을 이용할 수 있다. (권한: 관리자 / 편집 / 조회)',
  '기준코드 DB를 먼저 익힌다 — JS 대표코드와 고객사 연결품목의 관계를 이해.',
  '고객사 탭에서 주문서(PO)를 업로드한다.',
  '부족자재 탭에서 PO 대비 소요·부족수량과 상위 프로젝트(품의 근거)를 확인한다.',
  '구매발주로 부족분을 발주하고 발주서 양식을 내려받는다.',
  '입고처리에서 들어온 자재를 입고 등록한다.',
  '출고·불출에서 PO 기준으로 자재를 불출하고 미불출을 관리한다.',
  '마스터 관제탑에서 회사 전체 흐름(발주·재고·생산·납기)을 한눈에 점검한다.',
]

const MENU_GUIDE = [
  { group:'상단', items:[
    { name:'대시보드', desc:'오늘 할 일 요약(발주/입고/미불출) + 할일·이슈 통합 관리' },
    { name:'주간업무보고 / 주간보고 업로드', desc:'주간 단위 업무 보고 작성·업로드' },
    { name:'매입 현황', desc:'고객사별 월 매입 금액 현황' },
  ]},
  { group:'공통 업무', items:[
    { name:'견적입력', desc:'협력사 견적서 입력 — 단가변동이력으로 연결' },
    { name:'입고', desc:'구매발주 건의 실물 입고 처리' },
    { name:'출고', desc:'PO 기준 자재불출 + 미불출 추적 (다중 PO 일괄 불출, 납기순 배분)' },
    { name:'재고현황', desc:'품목별 현재고 — 부족자재·출고 계산의 기준' },
  ]},
  { group:'고객사 (AX/ED/VM/CSK)', items:[
    { name:'고객사 PO', desc:'이카운트 주문서 업로드·관리' },
    { name:'부족자재', desc:'PO × BOM 소요 − 재고·입고예정 = 부족수량. 상위 프로젝트(품의 근거) 자동 연결' },
    { name:'구매발주', desc:'부족분 발주 + 이카운트 발주서 양식 내려받기' },
    { name:'포캐스트', desc:'고객사 수요예측 관리 — LT 긴 자재를 PO 전에 선발주해 납기 단축' },
    { name:'BOM / 소요량 조회', desc:'고객사별 BOM 업로드 및 소요량 조회' },
  ]},
  { group:'의사결정 도구', items:[
    { name:'마스터 관제탑', desc:'발주·재고·생산·납기를 신호등 3단계(🔴즉시/🟡이번주/🟢모니터링)로 통합 모니터링' },
    { name:'What-if 시뮬레이터', desc:'입고지연·수요증감·안전버퍼(%)를 바꿔 "어디가 터지나"를 미리 실험 (실데이터 안 바뀜)' },
    { name:'인사이트 (관리자)', desc:'단가 이상 감지(PPV) · 공급처 평가 · 적시 납품률 · 시스템 활동 추적' },
    { name:'Shortage 예측', desc:'BOM 재귀 전개로 미래 자재부족을 월별 예측. 재고관리 제외/재계산' },
  ]},
  { group:'생산 관리', items:[
    { name:'생산 대시보드', desc:'생산 호기 일정을 달력·공정별(PD BOX)로 관리. PO와 자동 연동' },
    { name:'생산 관리', desc:'호기별 가공물 입고·하네스·전장 진행 현황 관리' },
  ]},
  { group:'기초자료', items:[
    { name:'기준코드 DB', desc:'JS 대표코드 ↔ 고객사 연결품목 마스터 (채번 포함). 검색: 품명·제조사·구매처로도 찾을 수 있고, 17* 처럼 입력하면 17로 시작하는 품번만 검색' },
    { name:'협력사', desc:'매입처(거래처) 마스터' },
    { name:'단가변동이력', desc:'품목별 단가 추이를 제조사별·매입처별로 추적' },
  ]},
  { group:'연동/관리', items:[
    { name:'ERP 연동', desc:'이카운트 양식 import/export 허브' },
    { name:'관리자', desc:'시스템 관리 (관리자 전용)' },
    { name:'회원 관리', desc:'가입 신청 승인/거절 + 권한 설정(관리자/편집/조회) — 관리자 전용' },
  ]},
]

function SysBadge({ sys }) {
  const isErp = sys === '이카운트'
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold flex-shrink-0
      ${isErp ? 'bg-blue-50 text-blue-600' : 'bg-indigo-50 text-indigo-600'}`}>{sys}</span>
  )
}

export default function Help() {
  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-lg font-bold text-slate-900">도움말 · 업무 안내</h1>
        <p className="text-xs text-slate-400 mt-1">신규 입사자를 위한 셀프 가이드 — 이 포털이 어떤 흐름으로 돌아가는지 정리했습니다.</p>
      </div>

      {/* 시작 가이드 */}
      <section className="rounded-xl border border-indigo-200 bg-indigo-50/40 p-4">
        <p className="text-sm font-bold text-indigo-700 mb-3">처음이라면 이 순서로</p>
        <ol className="space-y-2">
          {START_STEPS.map((s, i) => (
            <li key={i} className="flex items-start gap-2.5 text-xs text-slate-700">
              <span className="flex-shrink-0 w-5 h-5 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-[10px]">{i+1}</span>
              <span className="leading-relaxed">{s}</span>
            </li>
          ))}
        </ol>
      </section>

      {/* 전체 업무 플로우 */}
      <section>
        <p className="text-sm font-bold text-slate-800 mb-1">전체 업무 플로우</p>
        <p className="text-xs text-slate-400 mb-3">
          <span className="inline-flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500"/>이카운트</span>
          <span className="mx-2 inline-flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-indigo-500"/>포털</span>
          사이를 도는 닫힌 루프입니다.
        </p>
        <div className="space-y-1">
          {FLOW.map((f, i) => (
            <div key={i}>
              <div className={`rounded-xl border p-3 flex items-center gap-3
                ${f.sys==='이카운트' ? 'border-blue-200 bg-blue-50/40' : 'border-indigo-200 bg-indigo-50/30'}`}>
                <span className="flex-shrink-0 w-6 h-6 rounded-full bg-white border border-slate-200 text-slate-500 font-bold flex items-center justify-center text-[11px]">{i+1}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-slate-800">{f.title}</span>
                    <SysBadge sys={f.sys} />
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">{f.desc}</p>
                </div>
              </div>
              {i < FLOW.length-1 && <div className="text-center text-slate-300 text-xs leading-none py-0.5">↓</div>}
            </div>
          ))}
          <div className="text-center text-xs text-slate-400 pt-1">↻ 출고가 끝나면 다음 수주로 순환</div>
        </div>
      </section>

      {/* 메뉴별 설명 */}
      <section>
        <p className="text-sm font-bold text-slate-800 mb-3">메뉴별 설명</p>
        <div className="space-y-4">
          {MENU_GUIDE.map(g => (
            <div key={g.group}>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{g.group}</p>
              <div className="rounded-xl border border-slate-200 divide-y divide-slate-100">
                {g.items.map(it => (
                  <div key={it.name} className="flex items-start gap-3 px-4 py-2.5">
                    <span className="text-xs font-bold text-slate-700 w-40 flex-shrink-0">{it.name}</span>
                    <span className="text-xs text-slate-500 flex-1 leading-relaxed">{it.desc}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      <p className="text-[11px] text-slate-300 pt-2">모르는 부분이 있으면 각 페이지를 직접 눌러보며 익히세요. 데이터는 이카운트에서 내려받아 올리고, 포털에서 만든 자료는 이카운트 양식으로 내보냅니다.</p>
    </div>
  )
}
